from http.server import HTTPServer, SimpleHTTPRequestHandler
import os

class CustomHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/index':
            self.path = '/templates/index.html'
        return SimpleHTTPRequestHandler.do_GET(self)

os.makedirs('templates', exist_ok=True)
print("Serveur démarré sur http://localhost:8000")
HTTPServer(('', 8000), CustomHandler).serve_forever()