import requests
import json
from typing import List, Dict, Optional
from datetime import datetime
import re

def parse_version(version_str: str) -> tuple:
    """
    Parse a version string into a tuple of integers for comparison.
    Example: '8.5.0' -> (8, 5, 0), '11.0.0' -> (11, 0, 0)
    """
    # Remove any non-numeric characters except dots and convert to tuple of ints
    parts = re.split(r'[.-]', version_str)
    return tuple(int(part) if part.isdigit() else 0 for part in parts)

def version_in_range(version: str, range_str: str) -> bool:
    """
    Check if a version is within a given range string.
    Examples of range_str: '8.5.0 to 8.5.100', '>= 11.0.0', '<= 9.0.0', etc.
    """
    version_tuple = parse_version(version)
    
    if ' to ' in range_str:
        # Range like "8.5.0 to 8.5.100"
        start, end = range_str.split(' to ')
        start_tuple = parse_version(start.strip())
        end_tuple = parse_version(end.strip())
        return start_tuple <= version_tuple <= end_tuple
    
    elif range_str.startswith('>='):
        # Version like ">= 11.0.0"
        min_version = range_str[2:].strip()
        min_tuple = parse_version(min_version)
        return version_tuple >= min_tuple
    
    elif range_str.startswith('<='):
        # Version like "<= 9.0.0"
        max_version = range_str[3:].strip()
        max_tuple = parse_version(max_version)
        return version_tuple <= max_tuple
    
    elif range_str.startswith('<'):
        # Version like "< 9.0.0"
        max_version = range_str[1:].strip()
        max_tuple = parse_version(max_version)
        return version_tuple < max_tuple
    
    elif range_str.startswith('>'):
        # Version like "> 8.0.0"
        min_version = range_str[1:].strip()
        min_tuple = parse_version(min_version)
        return version_tuple > min_tuple
    
    else:
        # Exact match
        range_tuple = parse_version(range_str)
        return version_tuple == range_tuple

def search_cve(product_name: str, start_date: str = None, end_date: str = None, target_version: str = None) -> List[Dict]:
    """
    Search for all CVEs related to a specific product without sending date filters to server
    Date filtering is done locally after retrieval
    
    Args:
        product_name (str): Name of the product to search for
        start_date (str): Start date in YYYY-MM-DD format (optional) - used for local filtering
        end_date (str): End date in YYYY-MM-DD format (optional) - used for local filtering
        target_version (str): Specific version to check if affected (optional)
    
    Returns:
        List[Dict]: List of CVE details filtered by date range and version (if provided)
    """
    base_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    
    all_cves = []
    start_index = 0
    total_results = 0
    
    # Prepare parameters - NO date filters sent to server
    params = {
        'keywordSearch': product_name,
        'resultsPerPage': 2000,  # Maximum allowed per request
        'startIndex': start_index
    }
    
    # Validate dates if provided
    validated_start_date = None
    validated_end_date = None
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            # Check if date is not in the future
            if start_dt.date() > datetime.now().date():
                print(f"Start date {start_date} is in the future. Using today's date instead.")
                start_date = datetime.now().strftime('%Y-%m-%d')
            validated_start_date = start_date
        except ValueError:
            print(f"Invalid start date format: {start_date}. Please use YYYY-MM-DD format.")
            return []
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')
            # Check if date is not in the future
            if end_dt.date() > datetime.now().date():
                print(f"End date {end_date} is in the future. Using today's date instead.")
                end_date = datetime.now().strftime('%Y-%m-%d')
            validated_end_date = end_date
        except ValueError:
            print(f"Invalid end date format: {end_date}. Please use YYYY-MM-DD format.")
            return []
    
    # Check if start date is after end date
    if validated_start_date and validated_end_date:
        start_dt = datetime.strptime(validated_start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(validated_end_date, '%Y-%m-%d')
        if start_dt.date() > end_dt.date():
            print("Start date cannot be after end date. Please correct the dates.")
            return []
    
    while True:
        params['startIndex'] = start_index
        
        try:
            response = requests.get(base_url, params=params)
            response.raise_for_status()
            
            data = response.json()
            cve_items = data.get('vulnerabilities', [])
            total_results = data.get('totalResults', 0)
            
            # Add current batch of CVEs to the list
            for item in cve_items:
                cve = item.get('cve', {})
                
                # Extract basic CVE information
                cve_id = cve.get('id', 'N/A')
                description = cve.get('descriptions', [{}])[0].get('value', 'No description available')
                
                # Extract metrics (CVSS scores)
                metrics = cve.get('metrics', {})
                cvss_data = {}
                
                # Look for CVSS v3.x or v2 data
                if 'cvssMetricV31' in metrics and metrics['cvssMetricV31']:
                    cvss_data = metrics['cvssMetricV31'][0].get('cvssData', {})
                elif 'cvssMetricV30' in metrics and metrics['cvssMetricV30']:
                    cvss_data = metrics['cvssMetricV30'][0].get('cvssData', {})
                elif 'cvssMetricV2' in metrics and metrics['cvssMetricV2']:
                    cvss_data = metrics['cvssMetricV2'][0].get('cvssData', {})
                
                # Extract CVSS score and severity
                cvss_score = cvss_data.get('baseScore', 'N/A')
                cvss_severity = cvss_data.get('baseSeverity', 'N/A')
                
                # Extract published and last modified dates
                published_date = cve.get('published', 'N/A')
                last_modified = cve.get('lastModified', 'N/A')
                
                # Extract references
                references = [ref.get('url', '') for ref in cve.get('references', [])]
                
                # Extract affected product versions
                affected_products = []
                configurations = cve.get('configurations', [])
                for config in configurations:
                    nodes = config.get('nodes', [])
                    for node in nodes:
                        cpe_matches = node.get('cpeMatch', [])
                        for cpe_match in cpe_matches:
                            if cpe_match.get('vulnerable', False):
                                cpe_uri = cpe_match.get('criteria', '')
                                version_start = cpe_match.get('versionStartIncluding', '')
                                version_end = cpe_match.get('versionEndIncluding', '')
                                version_exact = cpe_match.get('versionEndExcluding', '')
                                
                                # Extract version information
                                if version_start and version_end:
                                    affected_products.append(f"{version_start} to {version_end}")
                                elif version_start:
                                    affected_products.append(f">= {version_start}")
                                elif version_end:
                                    affected_products.append(f"<= {version_end}")
                                elif version_exact:
                                    affected_products.append(f"< {version_exact}")
                                else:
                                    # Try to extract from CPE URI
                                    if 'version:' in cpe_uri:
                                        version_match = re.search(r'version:([^:]+)', cpe_uri)
                                        if version_match:
                                            affected_products.append(version_match.group(1))
                
                # Remove duplicates
                affected_products = list(set(affected_products))
                
                # Check if this CVE affects the target version (if provided)
                is_affected = False
                if target_version and affected_products:
                    for range_str in affected_products:
                        if version_in_range(target_version, range_str):
                            is_affected = True
                            break
                
                # Create CVE detail dictionary
                cve_detail = {
                    'id': cve_id,
                    'description': description,
                    'score': cvss_score,
                    'severity': cvss_severity,
                    'published_date': published_date,
                    'last_modified': last_modified,
                    'references': references,
                    'affected_versions': affected_products,
                    'is_affected_by_version': is_affected if target_version else True  # If no version specified, show all
                }
                
                all_cves.append(cve_detail)
            
            # Check if we've retrieved all results
            if start_index + len(cve_items) >= total_results:
                break
            
            # Update start index for next request
            start_index += len(cve_items)
            
            print(f"Retrieved {len(all_cves)}/{total_results} CVEs...")
            
        except requests.exceptions.RequestException as e:
            print(f"Error making request: {e}")
            break
        except json.JSONDecodeError:
            print("Error decoding JSON response")
            break
        except Exception as e:
            print(f"Unexpected error: {e}")
            break
    
    # LOCAL FILTERING: Filter results based on date range after retrieval
    if validated_start_date or validated_end_date:
        filtered_cves = []
        for cve in all_cves:
            published = cve['published_date']
            if published != 'N/A':
                # Extract date part only (YYYY-MM-DD)
                pub_date_str = published.split('T')[0]
                try:
                    pub_date = datetime.strptime(pub_date_str, '%Y-%m-%d').date()
                    
                    # Check if date is within range
                    in_range = True
                    if validated_start_date:
                        start_dt = datetime.strptime(validated_start_date, '%Y-%m-%d').date()
                        if pub_date < start_dt:
                            in_range = False
                    if validated_end_date:
                        end_dt = datetime.strptime(validated_end_date, '%Y-%m-%d').date()
                        if pub_date > end_dt:
                            in_range = False
                    
                    if in_range:
                        filtered_cves.append(cve)
                except ValueError:
                    # If date parsing fails, exclude it
                    continue
            else:
                # If no published date, exclude it from filtered results
                continue
        
        all_cves = filtered_cves
        print(f"After local date filtering: {len(all_cves)} CVEs remain.")
    
    # VERSION FILTERING: Only show CVEs that affect the target version
    if target_version:
        version_filtered_cves = []
        for cve in all_cves:
            if cve['is_affected_by_version']:
                version_filtered_cves.append(cve)
        
        all_cves = version_filtered_cves
        print(f"After version filtering for '{target_version}': {len(all_cves)} CVEs remain.")
    
    return all_cves

def process_cve_results(results: List[Dict]) -> List[Dict]:
    """
    Process CVE search results and return a formatted list
    
    Args:
        results (List[Dict]): Raw CVE results from search function
    
    Returns:
        List[Dict]: Processed CVE data
    """
    processed_results = []
    
    for cve in results:
        processed_cve = {
            'cve_id': cve.get('id', 'N/A'),
            'summary': cve.get('description', 'No description available')[:200] + '...' if len(cve.get('description', '')) > 200 else cve.get('description', 'No description available'),
            'cvss_score': cve.get('score', 'N/A'),
            'severity': cve.get('severity', 'N/A'),
            'published': cve.get('published_date', 'N/A'),
            'last_modified': cve.get('last_modified', 'N/A'),
            'references_count': len(cve.get('references', [])),
            'all_references': cve.get('references', []),
            'affected_versions': cve.get('affected_versions', []),
            'is_affected_by_version': cve.get('is_affected_by_version', True)
        }
        processed_results.append(processed_cve)
    
    return processed_results

def is_poc_url(url: str) -> bool:
    """Determine if a URL is likely a Proof of Concept (PoC)"""
    if not url:
        return False
    url_lower = url.lower()
    poc_indicators = [
        'github.com/exploitdb', 'github.com/exploit-db',
        'github.com/.../exploit', 'github.com/.../poc',
        'github.com/.../cve-', 'github.com/.../poC',
        'gitlab.com/.../exploit', 'gitlab.com/.../poc',
        'raw.githubusercontent.com/.../.py', 'raw.githubusercontent.com/.../.sh',
        'exploitdb.com', 'packetstormsecurity.com',
        'www.securityfocus.com/bid', 'www.offensive-security.com'
    ]
    return any(indicator in url_lower for indicator in poc_indicators)

def display_cve_details(cve_list: List[Dict], target_version: str = None):
    """
    Display CVE details in a formatted way with simplified date format
    
    Args:
        cve_list (List[Dict]): List of processed CVE data
        target_version (str): The version that was searched for (if any)
    """
    if not cve_list:
        if target_version:
            print(f"No CVEs found for the given product and version '{target_version}'.")
        else:
            print("No CVEs found for the given product and date range.")
        return
    
    print(f"\nFound {len(cve_list)} CVE(s) in the specified criteria:\n")
    print("="*80)
    
    for i, cve in enumerate(cve_list, 1):
        print(f"CVE #{i}:")
        print(f"  ID: {cve['cve_id']}")
        print(f"  Summary: {cve['summary']}")
        print(f"  CVSS Score: {cve['cvss_score']}")
        print(f"  Severity: {cve['severity']}")
        
        # Format published date - keep only date part (YYYY-MM-DD)
        published = cve['published']
        if published != 'N/A':
            published = published.split('T')[0]  # Keep only YYYY-MM-DD
        print(f"  Published: {published}")
        
        # Format last modified date - keep full datetime (YYYY-MM-DD HH:MM:SS.mmm)
        last_modified = cve['last_modified']
        if last_modified != 'N/A':
            last_modified = last_modified.replace('T', ' ')  # Replace T with space
        print(f"  Last Modified: {last_modified}")
        
        # Display affected product versions
        if cve['affected_versions']:
            versions_str = ', '.join(cve['affected_versions'])
            print(f"  Affected Versions: {versions_str}")
        else:
            print(f"  Affected Versions: N/A")
        
        # Display if the target version is affected (if version was specified)
        if target_version:
            status = "YES" if cve['is_affected_by_version'] else "NO"
            print(f"  Affects Version '{target_version}': {status}")
        
        print(f"  References Count: {cve['references_count']}")
        
        # Display all references
        all_refs = cve['all_references']
        if all_refs:
            print("  All References:")
            for idx, ref_url in enumerate(all_refs, 1):
                is_poc = is_poc_url(ref_url)
                poc_marker = " ✅ PoC" if is_poc else ""
                print(f"    {idx}. {ref_url}{poc_marker}")
        else:
            print("  All References: N/A")
        
        print("-" * 80)

# Example usage
if __name__ == "__main__":
    # Get user input
    product = input("Enter product name to search for CVEs: ")
    
    print("\nOptional: Enter version to check if affected (e.g., 8.5.0)")
    version_input = input("Version (or press Enter to skip): ").strip()
    target_version = version_input if version_input else None
    
    print("\nOptional: Enter date range for filtering (format: YYYY-MM-DD)")
    start_date_input = input("Start date (or press Enter to skip): ").strip()
    start_date = start_date_input if start_date_input else None
    
    end_date_input = input("End date (or press Enter to skip): ").strip()
    end_date = end_date_input if end_date_input else None
    
    print(f"\nSearching for all CVEs related to '{product}'...")
    if target_version:
        print(f"Version filter: Only showing CVEs that affect version '{target_version}'")
    if start_date or end_date:
        start_info = start_date if start_date else 'beginning'
        end_info = end_date if end_date else 'present'
        date_info = f" from {start_info} to {end_info}"
        print(f"Date filter: {date_info}")
        print("Note: Date filtering is done locally after retrieving all results.")
    
    raw_results = search_cve(product, start_date, end_date, target_version)
    
    # Process the results
    processed_results = process_cve_results(raw_results)
    
    # Display the CVE details
    display_cve_details(processed_results, target_version)