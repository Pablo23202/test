import requests
import json
import sys

def send_results_to_server(results, server_url='http://127.0.0.1:5001/api/results', source='Default'):
    payload = {
        'cves': results,
        'source': source
    }
    try:
        response = requests.post(server_url, json=payload)
        if response.status_code == 200:
            print(f"Résultats envoyés au serveur ({len(results)} CVEs)")
        else:
            print(f"Erreur: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Erreur de connexion au serveur: {e}")

def receive_results_from_searcher():
    """Lit les résultats d'un searcher externe et les envoie au serveur"""
    # Exemple de données reçues (en pratique, cela pourrait provenir d'un fichier, d'une API, etc.)
    example_results = [
        {
            'id': 'CVE-2023-1234',
            'published': '2023-01-01T00:00:00.000',
            'cvss_score': 7.5,
            'cvss_severity': 'HIGH',
            'description': 'Vulnérabilité critique dans...'
        }
    ]
    send_results_to_server(example_results, source='Example Searcher')

if __name__ == '__main__':
    receive_results_from_searcher()