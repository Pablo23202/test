from tree_sitter import Language, Parser
import tree_sitter_c_sharp
import re

# ======================
# Setup Tree-sitter
# ======================
CSHARP_LANGUAGE = Language(tree_sitter_c_sharp.language())
parser = Parser(CSHARP_LANGUAGE)  # instanciation directe

# ======================
# Extraction C# depuis ASPX
# ======================
def extract_csharp_from_aspx(file_path):
    """Extract C# code from ASPX file and normalize single-line code."""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    blocks = []

    # Ignore <%@ ... %> directives
    pattern_server_script = r'<%(?!@)\s*(.*?)\s*%>'
    pattern_script_server = r'<script[^>]*runat\s*=\s*["\']server["\'][^>]*>(.*?)</script>'

    blocks += re.findall(pattern_server_script, content, re.DOTALL)
    blocks += re.findall(pattern_script_server, content, re.DOTALL | re.IGNORECASE)

    blocks = [b.strip() for b in blocks if b.strip()]

    # Normaliser les accolades pour parser correctement Tree-sitter
    normalized_blocks = []
    for block in blocks:
        block = block.replace('{', '{\n').replace('}', '\n}')
        normalized_blocks.append(block)

    return '\n'.join(normalized_blocks)

# ======================
# Parcours AST
# ======================
def extract_nodes(tree, node_types):
    """Récupère tous les nœuds correspondants aux types donnés."""
    result = []

    def traverse(node):
        if node.type in node_types:
            result.append(node)
        for child in node.children:
            traverse(child)

    traverse(tree.root_node)
    return result

# ======================
# Extraction Variables
# ======================
def extract_variables(tree):
    variables = []
    for node in extract_nodes(tree, ['local_declaration_statement', 'field_declaration']):
        var_type = ""
        var_names = []

        for child in node.children:
            if child.type == 'variable_declaration':
                for decl_child in child.children:
                    if decl_child.type in ['predefined_type', 'identifier']:
                        if not var_type:
                            var_type = decl_child.text.decode('utf-8')
                    elif decl_child.type == 'variable_declarator':
                        for var_child in decl_child.children:
                            if var_child.type == 'identifier':
                                var_names.append(var_child.text.decode('utf-8'))

        for name in var_names:
            variables.append({
                'type': var_type,
                'name': name,
                'line': node.start_point[0] + 1
            })
    return variables

# ======================
# Extraction Fonctions
# ======================
def extract_functions(tree):
    functions = []
    for node in extract_nodes(tree, ['method_declaration']):
        method_name = ""
        return_type = ""
        modifiers = []
        parameters = []

        for child in node.children:
            if child.type == 'modifier':
                modifiers.append(child.text.decode('utf-8'))

        children_list = node.children
        i = 0
        while i < len(children_list):
            child = children_list[i]

            if child.type in ['predefined_type', 'identifier']:
                if i + 1 < len(children_list) and children_list[i + 1].type == 'parameter_list':
                    method_name = child.text.decode('utf-8')
                elif not return_type:
                    return_type = child.text.decode('utf-8')

            elif child.type == 'parameter_list':
                for param_node in child.children:
                    if param_node.type == 'parameter':
                        param_type = ""
                        param_name = ""
                        for p_child in param_node.children:
                            if p_child.type in ['predefined_type', 'identifier']:
                                if not param_type:
                                    param_type = p_child.text.decode('utf-8')
                                elif not param_name:
                                    param_name = p_child.text.decode('utf-8')
                        if param_type and param_name:
                            parameters.append({'type': param_type, 'name': param_name})
            i += 1

        if method_name:
            functions.append({
                'name': method_name,
                'return_type': return_type,
                'modifiers': modifiers,
                'parameters': parameters,
                'line': node.start_point[0] + 1
            })

    return functions

# ======================
# Extraction Classes
# ======================
def extract_classes(tree):
    classes = []

    for node in extract_nodes(tree, ['class_declaration']):
        class_name = ""
        fields = []
        methods = []

        for child in node.children:
            if child.type == 'identifier':
                class_name = child.text.decode('utf-8')
            elif child.type == 'declaration_list':
                for decl in child.children:
                    if decl.type == 'field_declaration':
                        sub_tree = parser.parse(decl.text.encode('utf-8'))
                        fields += extract_variables(sub_tree)
                    elif decl.type == 'method_declaration':
                        sub_tree = parser.parse(decl.text.encode('utf-8'))
                        methods += extract_functions(sub_tree)

        if class_name:
            classes.append({
                'name': class_name,
                'fields': fields,
                'methods': methods,
                'line': node.start_point[0] + 1
            })

    return classes

# ======================
# Interface de traitement
# ======================
def process_aspx_file(file_path):
    csharp_code = extract_csharp_from_aspx(file_path)
    tree = parser.parse(csharp_code.encode('utf-8'))

    return {
        'variables': extract_variables(tree),
        'functions': extract_functions(tree),
        'classes': extract_classes(tree)
    }

# ======================
# Exemple d'utilisation
# ======================
if __name__ == "__main__":
    # Tout le code C# sur une seule ligne
    aspx_content = '''<%@ Page Language="C#" %><script runat="server">protected string GetWelcomeMessage(string name){return $"Bienvenue, {name}!";} protected int AddNumbers(int a,int b){return a+b;} protected void Page_Load(object sender,EventArgs e){int x=5;int y=10;}</script>'''

    with open("test.aspx", "w", encoding="utf-8") as f:
        f.write(aspx_content)

    result = process_aspx_file("test.aspx")

    print("Variables:")
    for v in result['variables']:
        print(f"  Line {v['line']}: {v['type']} {v['name']}")

    print("\nFunctions:")
    for f in result['functions']:
        params = ", ".join([f"{p['type']} {p['name']}" for p in f['parameters']])
        mods = " ".join(f['modifiers']) + " " if f['modifiers'] else ""
        print(f"  Line {f['line']}: {mods}{f['return_type']} {f['name']}({params})")

    print("\nClasses:")
    for c in result['classes']:
        print(f"  Line {c['line']}: Class {c['name']}")
        for fld in c['fields']:
            print(f"    Field: {fld['type']} {fld['name']}")
        for mtd in c['methods']:
            params = ", ".join([f"{p['type']} {p['name']}" for p in mtd['parameters']])
            mods = " ".join(mtd['modifiers']) + " " if mtd['modifiers'] else ""
            print(f"    Method: {mods}{mtd['return_type']} {mtd['name']}({params})")
