from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
import time

def search_exploit_db_selenium(query):
    # Configure Selenium avec Chrome
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Mode sans tête (pas de fenêtre graphique)
    
    # Chemin vers ChromeDriver (remplace par ton propre chemin)
    driver_path = '/path/to/chromedriver'
    
    # Lancer le navigateur Chrome
    driver = webdriver.Chrome(executable_path=driver_path, options=chrome_options)
    
    # Accéder à la page de recherche Exploit-DB
    driver.get('https://www.exploit-db.com/search')
    
    # Trouver le champ de recherche et y entrer le mot-clé
    search_box = driver.find_element(By.NAME, 'q')
    search_box.clear()
    search_box.send_keys(query)
    search_box.send_keys(Keys.RETURN)
    
    # Attendre quelques secondes pour que la page se charge
    time.sleep(5)
    
    # Extraire les résultats
    exploits = []
    rows = driver.find_elements(By.CSS_SELECTOR, 'tr.search-result')
    
    for row in rows:
        title = row.find_element(By.CSS_SELECTOR, 'a').text
        link = row.find_element(By.CSS_SELECTOR, 'a').get_attribute('href')
        description = row.find_element(By.CSS_SELECTOR, 'td.text-muted').text if row.find_element(By.CSS_SELECTOR, 'td.text-muted') else 'N/A'
        exploit_id = row.find_element(By.CSS_SELECTOR, 'td.text-center').text if row.find_element(By.CSS_SELECTOR, 'td.text-center') else 'N/A'
        
        exploit = {
            'title': title,
            'link': link,
            'description': description,
            'exploit_id': exploit_id
        }
        exploits.append(exploit)
    
    # Fermer le navigateur
    driver.quit()
    
    return exploits

# Exemple de recherche d'exploits pour "tomcat"
query = "tomcat"
exploits = search_exploit_db_selenium(query)

# Affichage des exploits
if exploits:
    for exploit in exploits:
        print(f"Exploit Title: {exploit['title']}")
        print(f"Link: {exploit['link']}")
        print(f"Exploit ID: {exploit['exploit_id']}")
        print(f"Description: {exploit['description']}")
        print("-" * 80)
else:
    print("Aucun exploit trouvé.")
